#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 15:00:47 2019

@author: lujuanjuan
"""

name="BSMILES"